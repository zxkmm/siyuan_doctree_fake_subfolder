# Doctree Nested folder support for SiYuan

This plugin is protected by AGLP 3.0 license

- I know it's painful every time you open secondary or multi-level folders. This plugin will free you from that.
- In the settings, fill in emojis. For example, if you enter "🗃️,📂,📁", all documents with these three emojis will be treated as sub-notebooks. You can click to expand them, and clicking won't enter the document (but your data won't be lost).
- If you fill in a document ID in the settings, that document will be treated as a sub-notebook. You can click to expand it, and clicking won't enter the document (but your data won't be lost).

## Credit
- [wilsons](https://ld246.com/member/wilsons) : Provided very helpful assistance in designing the fully automated mode. Thank you!
- [OpaqueGlass](https://github.com/OpaqueGlass) : Although this plugin does not use OpaqueGlass’s exact code, I have more or less been inspired by OpaqueGlass’s [syplugin-doubleClickFileTree](https://github.com/OpaqueGlass/syplugin-doubleClickFileTree) project, as I read their code before writing this plugin. Thank you!



