# 文档树多层文件夹
## 恳请：
## 如果您有空的话，恳求您给我的GitHub仓库点一个**免费**的Star（星星）。
## 本插件是完全开源免费的，我相信任何经营模式都有可取之处，本插件的开源免费经营模式，需要的就是您的鼓励。
## 我是毕业大学生，在艰难的就业市场中正在寻找工作。
## 您给我点的免费Star将很大程度帮助我解决温饱问题，再次感谢！
## 
## 功能
 - 我知道你每次点开二级或多层文件夹很痛苦。这个插件将解放你。
 - 设置项中填入emoji,例如你填入"🗃️,📂,📁"的话，所有的这三个emoji文档都会被认为是子笔记本，你可以点击展开，点击不会进入文档（但你的数据不会丢失）
 - 设置项中填入文档ID，则这个文档会被视为是子笔记本，你可以点击展开，点击不会进入文档（但你的数据不会丢失）

# 致谢
- [wilsons](https://ld246.com/member/wilsons) : 在设计全自动模式时候对我提供了非常有用的帮助。谢谢！
- [OpaqueGlass](https://github.com/OpaqueGlass) : 虽然这个插件没有使用OpaqueGlass的确切代码，但我或多或少从OpaqueGlass的[syplugin-doubleClickFileTree](https://github.com/OpaqueGlass/syplugin-doubleClickFileTree)项目中得到过灵感，因为我在写这个插件之前就读了ta的代码。谢谢！